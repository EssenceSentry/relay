# Relay plugin bundle

Version: 1.0.4

Relay normally provides its current workflows directly through the remote MCP.
This compatibility bundle contains that authenticated MCP connection plus the
project-operations and source-cited dossier skills for Codex and Claude Code.
It connects to:

https://essencesentry.shop/mcp/

## Codex

Extract this archive, then run:

```bash
codex plugin marketplace add /absolute/path/to/relay-bundle
codex plugin add relay@relay
```

Start a new thread and invoke `$manage-project-knowledge` for project
operations or `$create-project-dossier` for a dossier, sales brief, success
story, or case study.

## Claude Code

Extract this archive, then run:

```bash
claude plugin marketplace add /absolute/path/to/relay-bundle
claude plugin install relay@relay
```

Run `/reload-plugins`, then invoke
`/relay:manage-project-knowledge` for project operations or
`/relay:create-project-dossier` for a dossier, sales brief, success
story, or case study.

For a temporary Claude Code session without marketplace installation:

```bash
claude --plugin-dir /absolute/path/to/relay-bundle/plugins/relay
```

The MCP requires a verified Relay login. Your client opens the configured
browser authorization flow when it connects.
